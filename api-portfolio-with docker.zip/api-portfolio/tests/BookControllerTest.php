<?php
namespace App\Tests;

use PHPUnit\Framework\TestCase;

class BookControllerTest extends TestCase
{
    public function testSomethingSimple()
    {
        $this->assertTrue(true);
    }
}
